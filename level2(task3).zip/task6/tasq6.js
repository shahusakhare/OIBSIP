let pendingList = document.getElementById("pendingList");
let completedList = document.getElementById("completedList");

function addTask() {
    let taskInput = document.getElementById("taskInput");
    let taskText = taskInput.value.trim();

    if (taskText !== "") {
        let taskItem = document.createElement("li");
        taskItem.innerHTML = `
            ${taskText}
            <button class="edit" onclick="editTask(this)">Edit</button>
            <button class="delete" onclick="deleteTask(this)">Delete</button>
            <button class="complete" onclick="completeTask(this)">Complete</button>
        `;
        pendingList.appendChild(taskItem);
        taskInput.value = "";  // Clear the input field
    } else {
        alert("Please enter a task.");
    }
}

function completeTask(button) {
    let taskItem = button.parentElement;
    taskItem.classList.add("complete");
    completedList.appendChild(taskItem);
    button.style.display = "none";  // Hide the 'Complete' button after completion
}

function deleteTask(button) {
    let taskItem = button.parentElement;
    taskItem.remove();
}

function editTask(button) {
    let taskItem = button.parentElement;
    let taskText = taskItem.firstChild.textContent.trim();
    let newTaskText = prompt("Edit your task:", taskText);

    if (newTaskText !== null && newTaskText.trim() !== "") {
        taskItem.firstChild.textContent = newTaskText;
    }
}
