let currentInput = '';
let operator = '';
let previousInput = '';
let result = 0;

document.getElementById('clear').addEventListener('click', function() {
    currentInput = '';
    operator = '';
    previousInput = '';
    result = 0;
    document.getElementById('screen').value = '';
});

document.getElementById('0').addEventListener('click', function() {
    currentInput += '0';
    updateScreen();
});

document.getElementById('1').addEventListener('click', function() {
    currentInput += '1';
    updateScreen();
});

document.getElementById('2').addEventListener('click', function() {
    currentInput += '2';
    updateScreen();
});

document.getElementById('3').addEventListener('click', function() {
    currentInput += '3';
    updateScreen();
});

document.getElementById('4').addEventListener('click', function() {
    currentInput += '4';
    updateScreen();
});

document.getElementById('5').addEventListener('click', function() {
    currentInput += '5';
    updateScreen();
});

document.getElementById('6').addEventListener('click', function() {
    currentInput += '6';
    updateScreen();
});

document.getElementById('7').addEventListener('click', function() {
    currentInput += '7';
    updateScreen();
});

document.getElementById('8').addEventListener('click', function() {
    currentInput += '8';
    updateScreen();
});

document.getElementById('9').addEventListener('click', function() {
    currentInput += '9';
    updateScreen();
});

document.getElementById('decimal').addEventListener('click', function() {
    if (!currentInput.includes('.')) {
        currentInput += '.';
        updateScreen();
    }
});

document.getElementById('add').addEventListener('click', function() {
    if (previousInput !== '') {
        calculate();
    }
    operator = '+';
    previousInput = currentInput;
    currentInput = '';
});

document.getElementById('subtract').addEventListener('click', function() {
    if (previousInput !== '') {
        calculate();
    }
    operator = '-';
    previousInput = currentInput;
    currentInput = '';
});

document.getElementById('multiply').addEventListener('click', function() {
    if (previousInput !== '') {
        calculate();
    }
    operator = '*';
    previousInput = currentInput;
    currentInput = '';
});

document.getElementById('divide').addEventListener('click', function() {
    if (previousInput !== '') {
        calculate();
    }
    operator = '/';
    previousInput = currentInput;
    currentInput = '';
});

document.getElementById('equals').addEventListener('click', function() {
    if (previousInput !== '') {
        calculate();
        currentInput = result.toString();
        previousInput = '';
        operator = '';
        updateScreen();
    }
});

function updateScreen() {
    document.getElementById('screen').value = currentInput;
}

function calculate() {
    let prev = parseFloat(previousInput);
    let curr = parseFloat(currentInput);

    switch (operator) {
        case '+':
            result = prev + curr;
            break;
        case '-':
            result = prev - curr;
            break;
        case '*':
            result = prev * curr;
            break;
        case '/':
            if (curr !== 0) {
                result = prev / curr;
            } else {
                result = 'Error';
            }
            break;
    }
    previousInput = result.toString();
    currentInput = '';
    updateScreen();
}
